import { Component } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = "";
  regForm:FormGroup;
  //abc = new FormControl();
  //creating instance variable
  //Build using formbuilder store it in regform
  constructor(private fb:FormBuilder){
  //console.log(this.fb.group({}));
  //Declared all variables in ts file in json object
   this.regForm= this.fb.group({
   'name':[],
   'age':[],
   'email':[],
   'password':[],
   'date':[]
   });
  }
  //function demo used in html file to print the output when we click submit button
  demo(){
  // it prints the values
    console.log(this.regForm.value)
    }
}
